# Author: Stefano Pilla - spilla@netschool.it - NET School Academy 

# Istruzione per creare una classe di nome TheSimplestClass
# La convenzione utilizzata è quella definita da PEP-8
# https://www.python.org/dev/peps/pep-0008/#package-and-module-names
# "Class names should normally use the CapWords convention."

class TheSimplestClass:
    pass


# Creiamo un oggetto della classe TheSimplestClass

myFirstObject = TheSimplestClass()

print(type(myFirstObject))


