# Author: Stefano Pilla - spilla@netschool.it - NET School Academy 

class Stack:    # Definiamo la classe Stack
    def __init__(self):    # Definiamo il costruttore (constructor function)
        print("Hi!")


stackObject = Stack()    # instanziamo l'oggetto

###################################

class Stack2:    # Definiamo la classe Stack2
    def __init__(self):    # Definiamo il costruttore (constructor function)
        self.stackList = [1]

stackObject2 = Stack2()    # instanziamo l'oggetto

print(len(stackObject2.stackList))  # Utilizzando la dotted notation per accedere ad una proprietà dell'oggetto 

###################################

class Stack3:
    def __init__(self):
        self.__stackList = [] # La notazione __ rende la proprietà privata quindi accessibile solo dalla classe e non dall'esterno


stackObject3 = Stack3()
print(len(stackObject3.__stackList)) # Se proviamo ad accedere alla prioprietà ci viene restituito un errore "AttributeError"