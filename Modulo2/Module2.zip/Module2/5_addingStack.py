# Author: Stefano Pilla - spilla@netschool.it - NET School Academy 

class Stack:
    def __init__(self):
        self.__stackList = []

    def push(self, val):
        self.__stackList.append(val)

    def pop(self):
        val = self.__stackList[-1]
        del self.__stackList[-1]
        return val


class AddingStack(Stack):
    def __init__(self):
        """
        Contrariamente a molti altri linguaggi, Python ci obbliga a invocare esplicitamente il costruttore di una superclasse. 
        Omettere questo passaggio può avere effetti indesiderati poichè l'oggetto verrà privato dell'elenco __stackList 
        e quindi non funzionerà correttamente.
        """
        Stack.__init__(self) # Con questa istruzione sto invocando il costruttore della classe Stack in modo esplicito
        self.__sum = 0
    
    # Questo metodo ci permette di leggere il valore attuale della variable __sum
    def getSum(self):
        return self.__sum

    # Questo metodo incremente il counter __sum e aggiunge il valore allo stack
    def push(self, val):
        self.__sum += val
        Stack.push(self, val)

    # Questo metodo decrementa il counter __sum e aggiunge il valore allo stack
    def pop(self):
        val = Stack.pop(self)
        self.__sum -= val
        return val


stackObject = AddingStack()

for i in range(5): # Per i che va da 0 a 4 incluso
    stackObject.push(i) # Aggiungo i all'oggetto stackObject
print(stackObject.getSum()) # Alla conclusione mostro il valore di __sum richiamando il metodo getsum()

for i in range(5):
    print(stackObject.pop())