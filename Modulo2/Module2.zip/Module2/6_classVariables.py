# Author: Stefano Pilla - spilla@netschool.it - NET School Academy 

class ExampleClass:
    def __init__(self, val):
        if val % 2 != 0:
            self.a = 1
        else:
            self.b = 1


exampleObject = ExampleClass(1)

print(exampleObject.a)
print(exampleObject.b)

# L'oggetto creato dal costruttore può avere solo uno dei due possibili attributi: a o b.
# Ecco il motivo dell'errore 


# E' possibile gestire l'errore con un try/except

try:
    print(exampleObject.b)
except AttributeError:
    pass
