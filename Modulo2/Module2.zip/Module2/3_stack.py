# Author: Stefano Pilla - spilla@netschool.it - NET School Academy 

class Stack:
    def __init__(self):
        self.__stackList = []

    """ 
    Nella defizione di un metodo è obbligatorio indicare anche il parametro "self"
    Consente al metodo di accedere alle proprietà e ai metodi dell'oggetto reale. 
    Non è possibile ometterlo. Ogni volta che Python invoca un metodo, invia implicitamente l'oggetto corrente come primo argomento.
    Ciò significa che un metodo è obbligato ad avere almeno un parametro, che viene utilizzato da Python stesso.
    """

    # La funzione push aggiunge in coda allo stack val
    def push(self, val):
            self.__stackList.append(val)

    # La funzione pop rimuove l'ultimo elemento dello stack
    def pop(self):
        val = self.__stackList[-1] # L'assegnazione viene fatta solo per ritornare il valore di val
        del self.__stackList[-1]
        return val


# Creiamo 2 stack
stackObject = Stack()
stackObject2 = Stack()

# Inseriamo 3 elementi nell'oggetto stackObject
stackObject.push(3)
stackObject.push(2)
stackObject.push(1)

# Inseriamo 3 elementi nell'oggetto stackObject2
stackObject2.push(4)
stackObject2.push(5)
stackObject2.push(6)

print("Questo è il contenuto di stackObject:")
print(stackObject.pop())
print(stackObject.pop())
print(stackObject.pop())

print("Questo è il contenuto di stackObject2:")
print(stackObject2.pop())
print(stackObject2.pop())
print(stackObject2.pop())

### Cosa succede con il seguente codice?

"""
stackObject.push(3)
stackObject2.push(stackObject.pop())

print(stackObject2.pop())
"""



